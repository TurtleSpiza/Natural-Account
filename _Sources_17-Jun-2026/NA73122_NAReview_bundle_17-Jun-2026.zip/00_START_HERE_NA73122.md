# NA73122 Garbage Collection - Bundle index (17-Jun-2026)

Mode A per-account review of 73122 Garbage Collection, branch 4090000, FY25/26.

Verdict: reconciles to SE2 to the cent ($21,876.60). Coding correct. No recode. AMBER on evidence completeness only.

Read NA73122_Verification_Record.md for the full four-limb assessment.

Contents:
- NA73122_Verification_Record.md  - four-limb review, reconciliation, register-row header
- NA73122_GENJNL_Recode.txt        - NIL recode (no recode required)
- NA73122_Evidence_Manifest.csv    - per-file SHA-256, GL ex-GST, invoice incl GST
- NA73122_Evidence/                - light artefacts + README; council-wide statements fingerprinted, held in source intake
- 00_Bundle_Manifest.csv           - deliverable hashes
- gen_manifest.py / verify_manifest.py - integrity gate

Correction note 17-Jun-2026: bundle created. Strict-verify PASS at seal.
