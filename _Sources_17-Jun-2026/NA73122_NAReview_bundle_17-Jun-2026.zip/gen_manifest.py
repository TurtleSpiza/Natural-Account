#!/usr/bin/env python3
"""Generate 00_Bundle_Manifest.csv: per-file SHA-256 over bundle deliverables.
Excludes the manifest itself, __pycache__, and raw intake under _Sources_*."""
import hashlib, os, csv, sys
ROOT=os.path.dirname(os.path.abspath(__file__))
MANIFEST='00_Bundle_Manifest.csv'
def excluded(rel):
    parts=rel.split(os.sep)
    if rel==MANIFEST: return True
    if '__pycache__' in parts: return True
    if parts[0].startswith('_Sources_'): return True
    return False
def sha256(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(65536),b''): h.update(b)
    return h.hexdigest()
rows=[]
for dp,dn,fn in os.walk(ROOT):
    dn[:]=[d for d in dn if d!='__pycache__']
    for name in fn:
        full=os.path.join(dp,name); rel=os.path.relpath(full,ROOT)
        if excluded(rel): continue
        rows.append([rel.replace(os.sep,'/'), sha256(full), os.path.getsize(full)])
rows.sort(key=lambda r:r[0])
with open(os.path.join(ROOT,MANIFEST),'w',newline='') as f:
    w=csv.writer(f); w.writerow(['relpath','sha256','bytes'])
    for r in rows: w.writerow(r)
print(f'gen_manifest: {len(rows)} files hashed -> {MANIFEST}')
