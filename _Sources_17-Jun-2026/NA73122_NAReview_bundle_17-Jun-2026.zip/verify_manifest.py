#!/usr/bin/env python3
"""Verify bundle against 00_Bundle_Manifest.csv. --strict fails on ANY mismatch,
missing, or unmanifested deliverable. Raw intake (_Sources_*) and __pycache__ ignored."""
import hashlib, os, csv, sys
ROOT=os.path.dirname(os.path.abspath(__file__))
MANIFEST='00_Bundle_Manifest.csv'
strict='--strict' in sys.argv
def excluded(rel):
    parts=rel.split(os.sep)
    if rel==MANIFEST: return True
    if '__pycache__' in parts: return True
    if parts[0].startswith('_Sources_'): return True
    return False
def sha256(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(65536),b''): h.update(b)
    return h.hexdigest()
man={}
mp=os.path.join(ROOT,MANIFEST)
if not os.path.exists(mp): print('FAIL: no manifest'); sys.exit(2)
with open(mp,newline='') as f:
    for row in csv.DictReader(f): man[row['relpath']]=row['sha256']
on_disk={}
for dp,dn,fn in os.walk(ROOT):
    dn[:]=[d for d in dn if d!='__pycache__']
    for name in fn:
        full=os.path.join(dp,name); rel=os.path.relpath(full,ROOT).replace(os.sep,'/')
        if excluded(rel): continue
        on_disk[rel]=sha256(full)
fails=[]
for rel,h in man.items():
    if rel not in on_disk: fails.append(f'MISSING {rel}')
    elif on_disk[rel]!=h: fails.append(f'MISMATCH {rel}')
for rel in on_disk:
    if rel not in man: fails.append(f'UNMANIFESTED {rel}')
if fails:
    print('STRICT VERIFY: FAIL'); [print(' ',x) for x in fails]
    sys.exit(1 if strict else 0)
print(f'STRICT VERIFY: PASS ({len(man)} files match)')
